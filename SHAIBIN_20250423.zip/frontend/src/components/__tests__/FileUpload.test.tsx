import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { FileUpload } from '../FileUpload';
import { fileService } from '../../services/fileService';
import { useMutation } from '@tanstack/react-query';

// Mock the file service
jest.mock('../../services/fileService', () => ({
  fileService: {
    uploadFile: jest.fn(),
  },
}));

// Mock the useMutation hook
jest.mock('@tanstack/react-query', () => ({
  useMutation: jest.fn(),
  useQueryClient: jest.fn(),
}));

describe('FileUpload Component', () => {
  const mockOnUploadSuccess = jest.fn();
  
  beforeEach(() => {
    // Reset mocks
    jest.clearAllMocks();
    
    // Setup useMutation mock
    (useMutation as jest.Mock).mockReturnValue({
      mutateAsync: jest.fn(),
      isPending: false,
    });
  });

  it('renders upload button initially', () => {
    render(<FileUpload onUploadSuccess={mockOnUploadSuccess} />);
    expect(screen.getByText('Select a file')).toBeInTheDocument();
  });

  it('handles file selection', async () => {
    render(<FileUpload onUploadSuccess={mockOnUploadSuccess} />);
    
    const file = new File(['test content'], 'test.txt', { type: 'text/plain' });
    const input = screen.getByTestId('file-input');
    
    fireEvent.change(input, { target: { files: [file] } });
    
    await waitFor(() => {
      expect(screen.getByText('test.txt')).toBeInTheDocument();
    });
  });

  it('handles drag and drop', async () => {
    render(<FileUpload onUploadSuccess={mockOnUploadSuccess} />);
    
    const file = new File(['test content'], 'test.txt', { type: 'text/plain' });
    const dropZone = screen.getByTestId('drop-zone');
    
    fireEvent.dragEnter(dropZone);
    fireEvent.dragOver(dropZone);
    fireEvent.drop(dropZone, {
      dataTransfer: {
        files: [file],
      },
    });
    
    await waitFor(() => {
      expect(screen.getByText('test.txt')).toBeInTheDocument();
    });
  });

  it('shows error message for invalid file', async () => {
    render(<FileUpload onUploadSuccess={mockOnUploadSuccess} />);
    
    const file = new File(['test content'], 'test.txt', { type: 'text/plain' });
    const input = screen.getByTestId('file-input');
    
    // Mock upload failure
    (fileService.uploadFile as jest.Mock).mockRejectedValue(new Error('Upload failed'));
    
    fireEvent.change(input, { target: { files: [file] } });
    fireEvent.click(screen.getByText('Upload File'));
    
    await waitFor(() => {
      expect(screen.getByText('Failed to upload file. Please try again.')).toBeInTheDocument();
    });
  });

  it('shows success message after successful upload', async () => {
    render(<FileUpload onUploadSuccess={mockOnUploadSuccess} />);
    
    const file = new File(['test content'], 'test.txt', { type: 'text/plain' });
    const input = screen.getByTestId('file-input');
    
    // Mock successful upload
    (fileService.uploadFile as jest.Mock).mockResolvedValue({ status: 'success' });
    
    fireEvent.change(input, { target: { files: [file] } });
    fireEvent.click(screen.getByText('Upload File'));
    
    await waitFor(() => {
      expect(screen.getByText('Upload Complete!')).toBeInTheDocument();
    });
  });

  it('shows preview for image files', async () => {
    render(<FileUpload onUploadSuccess={mockOnUploadSuccess} />);
    
    // Create a mock image file
    const file = new File(['fake image content'], 'test.jpg', { type: 'image/jpeg' });
    const input = screen.getByTestId('file-input');
    
    fireEvent.change(input, { target: { files: [file] } });
    
    await waitFor(() => {
      expect(screen.getByAltText('Preview')).toBeInTheDocument();
    });
  });

  it('clears selected file when cancel button is clicked', async () => {
    render(<FileUpload onUploadSuccess={mockOnUploadSuccess} />);
    
    const file = new File(['test content'], 'test.txt', { type: 'text/plain' });
    const input = screen.getByTestId('file-input');
    
    fireEvent.change(input, { target: { files: [file] } });
    fireEvent.click(screen.getByTestId('clear-button'));
    
    await waitFor(() => {
      expect(screen.queryByText('test.txt')).not.toBeInTheDocument();
    });
  });
}); 